package CartaRestaurante;

public class PlatoException extends RuntimeException {

	public PlatoException() {
		// TODO Auto-generated constructor stub
	}
	
	public PlatoException(String mensaje) {
		super (mensaje);
	}
}